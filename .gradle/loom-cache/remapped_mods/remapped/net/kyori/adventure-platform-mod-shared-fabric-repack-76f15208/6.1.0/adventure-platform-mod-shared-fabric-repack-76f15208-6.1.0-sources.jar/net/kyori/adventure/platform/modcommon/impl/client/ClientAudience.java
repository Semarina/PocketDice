/*
 * This file is part of adventure-platform-mod, licensed under the MIT License.
 *
 * Copyright (c) 2020-2024 KyoriPowered
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package net.kyori.adventure.platform.modcommon.impl.client;

import java.net.MalformedURLException;
import java.time.Duration;
import java.util.Objects;
import java.util.UUID;
import net.kyori.adventure.audience.MessageType;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.chat.ChatType;
import net.kyori.adventure.chat.SignedMessage;
import net.kyori.adventure.identity.Identity;
import net.kyori.adventure.inventory.Book;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.platform.modcommon.MinecraftAudiences;
import net.kyori.adventure.platform.modcommon.impl.AdventureCommon;
import net.kyori.adventure.platform.modcommon.impl.ControlledAudience;
import net.kyori.adventure.platform.modcommon.impl.GameEnums;
import net.kyori.adventure.platform.modcommon.impl.MinecraftAudiencesInternal;
import net.kyori.adventure.platform.modcommon.impl.accessor.minecraft.world.level.LevelAccess;
import net.kyori.adventure.platform.modcommon.impl.client.mixin.minecraft.resources.sounds.AbstractSoundInstanceAccess;
import net.kyori.adventure.pointer.Pointered;
import net.kyori.adventure.pointer.Pointers;
import net.kyori.adventure.resource.ResourcePackInfo;
import net.kyori.adventure.resource.ResourcePackRequest;
import net.kyori.adventure.resource.ResourcePackStatus;
import net.kyori.adventure.sound.Sound;
import net.kyori.adventure.sound.SoundStop;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import net.kyori.adventure.title.TitlePart;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.hud.MessageIndicator;
import net.minecraft.client.gui.screen.ingame.BookScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.sound.EntityTrackingSoundInstance;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.entity.Entity;
import net.minecraft.network.message.ChatVisibility;
import net.minecraft.network.message.MessageSignatureData;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.random.Random;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class ClientAudience implements ControlledAudience {
  private final MinecraftClient client;
  private final MinecraftClientAudiencesImpl controller;

  public ClientAudience(final MinecraftClient client, final MinecraftClientAudiencesImpl renderer) {
    this.client = client;
    this.controller = renderer;
  }

  @Override
  public @NotNull MinecraftAudiencesInternal controller() {
    return this.controller;
  }

  @Override
  public void sendMessage(final @NotNull Component message) {
    this.client.inGameHud.getChatHud().addMessage(this.controller.asNative(message));
  }

  private net.minecraft.network.message.MessageType.Parameters toMc(final ChatType.Bound bound) {
    return AdventureCommon.chatTypeToNative(bound, this.controller);
  }

  @Override
  public void sendMessage(final @NotNull Component message, final ChatType.@NotNull Bound boundChatType) {
    final net.minecraft.network.message.MessageType.Parameters bound = this.toMc(boundChatType);
    this.client.inGameHud.getChatHud().addMessage(bound.applyChatDecoration(this.controller.asNative(message)), null, MessageIndicator.notSecure());
  }

  @Override
  public void sendMessage(final @NotNull SignedMessage signedMessage, final ChatType.@NotNull Bound boundChatType) {
    final net.minecraft.network.message.MessageType.Parameters bound = this.toMc(boundChatType);
    final Component message = Objects.requireNonNullElse(signedMessage.unsignedContent(), Component.text(signedMessage.message()));

    this.client.inGameHud.getChatHud().addMessage(bound.applyChatDecoration(this.controller.asNative(message)), (MessageSignatureData) (Object) signedMessage.signature(), this.tag(signedMessage));
  }

  private MessageIndicator tag(final SignedMessage message) {
    if (message == null) {
      return null;
    } else if (message.isSystem()) {
      return MessageIndicator.system();
    } else if (message.unsignedContent() != null && !message.unsignedContent().equals(Component.text(message.message()))) {
      return MessageIndicator.modified(message.message());
    } else if (message.signature() == null) {
      return MessageIndicator.notSecure();
    }

    return null;
  }

  @Override
  public void deleteMessage(final SignedMessage.@NotNull Signature signature) {
    this.client.inGameHud.getChatHud().removeMessage((MessageSignatureData) (Object) signature);
  }

  @Override
  @Deprecated
  public void sendMessage(final Identity source, final @NotNull Component message, final @NotNull MessageType type) {
    if (this.client.shouldBlockMessages(source.uuid())) {
      return;
    }

    final ChatVisibility visibility = this.client.options.getChatVisibility().getValue();
    if (type == MessageType.CHAT) {
      // Add to chat queue (following delay and such)
      if (visibility == ChatVisibility.FULL) {
        this.client.inGameHud.getChatHud().addMessage(this.controller.asNative(message), null, null);
      }
    } else {
      // Add immediately as a system message
      if (visibility == ChatVisibility.FULL || visibility == ChatVisibility.SYSTEM) {
        this.client.inGameHud.getChatHud().addMessage(this.controller.asNative(message));
      }
    }
  }

  @Override
  public void sendActionBar(final @NotNull Component message) {
    this.client.inGameHud.setOverlayMessage(this.controller.asNative(message), false);
  }

  @Override
  public void showTitle(final @NotNull Title title) {
    final net.minecraft.text.@Nullable Text titleText = title.title() == Component.empty() ? null : this.controller.asNative(title.title());
    final net.minecraft.text.@Nullable Text subtitleText = title.subtitle() == Component.empty() ? null : this.controller.asNative(title.subtitle());
    final Title.@Nullable Times times = title.times();
    this.client.inGameHud.setTitle(titleText);
    this.client.inGameHud.setSubtitle(subtitleText);
    this.client.inGameHud.setTitleTicks(
      this.adventure$ticks(times == null ? null : times.fadeIn()),
      this.adventure$ticks(times == null ? null : times.stay()),
      this.adventure$ticks(times == null ? null : times.fadeOut())
    );
  }

  @Override
  public <T> void sendTitlePart(final @NotNull TitlePart<T> part, final @NotNull T value) {
    Objects.requireNonNull(value, "value");
    if (part == TitlePart.TITLE) {
      this.client.inGameHud.setTitle(this.controller.asNative((Component) value));
    } else if (part == TitlePart.SUBTITLE) {
      this.client.inGameHud.setSubtitle(this.controller.asNative((Component) value));
    } else if (part == TitlePart.TIMES) {
      final Title.Times times = (Title.Times) value;
      this.client.inGameHud.setTitleTicks(
        this.adventure$ticks(times.fadeIn()),
        this.adventure$ticks(times.stay()),
        this.adventure$ticks(times.fadeOut())
      );
    } else {
      throw new IllegalArgumentException("Unknown TitlePart '" + part + "'");
    }
  }

  private int adventure$ticks(final @Nullable Duration duration) {
    return duration == null || duration.getSeconds() == -1 ? -1 : (int) (duration.toMillis() / 50);
  }

  @Override
  public void clearTitle() {
    this.client.inGameHud.setTitle(null);
    this.client.inGameHud.setSubtitle(null);
  }

  @Override
  public void resetTitle() {
    this.client.inGameHud.setDefaultTitleFade();
    this.clearTitle();
  }

  @Override
  public void showBossBar(final @NotNull BossBar bar) {
    BossHealthOverlayBridge.listener(this.client.inGameHud.getBossBarHud(), this.controller).add(bar);
  }

  @Override
  public void hideBossBar(final @NotNull BossBar bar) {
    BossHealthOverlayBridge.listener(this.client.inGameHud.getBossBarHud(), this.controller).remove(bar);
  }

  private long seed(final @NotNull Sound sound) {
    if (sound.seed().isPresent()) {
      return sound.seed().getAsLong();
    } else {
      final @Nullable ClientPlayerEntity player = this.client.player;
      if (player != null) {
        return ((LevelAccess) player.method_37908()).accessor$threadSafeRandom().nextLong();
      } else {
        return 0l;
      }
    }
  }

  @Override
  public void playSound(final @NotNull Sound sound) {
    final @Nullable ClientPlayerEntity player = this.client.player;
    if (player != null) {
      this.playSound(sound, player.getX(), player.getY(), player.getZ());
    } else {
      // not in-game
      this.client.getSoundManager().play(new PositionedSoundInstance(MinecraftAudiences.asNative(sound.name()), GameEnums.SOUND_SOURCE.toMinecraft(sound.source()),
        sound.volume(), sound.pitch(), Random.create(this.seed(sound)), false, 0, SoundInstance.AttenuationType.NONE, 0, 0, 0, true));
    }
  }

  @Override
  public void playSound(final @NotNull Sound sound, final Sound.@NotNull Emitter emitter) {
    final Entity targetEntity;
    if (emitter == Sound.Emitter.self()) {
      targetEntity = this.client.player;
    } else if (emitter instanceof final Entity entity) {
      targetEntity = entity;
    } else {
      throw new IllegalArgumentException("Provided emitter '" + emitter + "' was not Sound.Emitter.self() or an Entity");
    }

    // Initialize with a placeholder event
    final EntityTrackingSoundInstance mcSound = new EntityTrackingSoundInstance(
      SoundEvents.ENTITY_ITEM_PICKUP,
      GameEnums.SOUND_SOURCE.toMinecraft(sound.source()),
      sound.volume(),
      sound.pitch(),
      targetEntity,
      this.seed(sound)
    );
    // Then apply the ResourceLocation of our real sound event
    ((AbstractSoundInstanceAccess) mcSound).setLocation(MinecraftAudiences.asNative(sound.name()));

    this.client.getSoundManager().play(mcSound);
  }

  @Override
  public void playSound(final @NotNull Sound sound, final double x, final double y, final double z) {
    this.client.getSoundManager().play(new PositionedSoundInstance(
      MinecraftAudiences.asNative(sound.name()),
      GameEnums.SOUND_SOURCE.toMinecraft(sound.source()),
      sound.volume(),
      sound.pitch(),
      Random.create(this.seed(sound)),
      false,
      0,
      SoundInstance.AttenuationType.LINEAR,
      x,
      y,
      z,
      false
    ));
  }

  @Override
  public void stopSound(final @NotNull SoundStop stop) {
    final @Nullable Key sound = stop.sound();
    final @Nullable Identifier soundIdent = sound == null ? null : MinecraftAudiences.asNative(sound);
    final Sound.@Nullable Source source = stop.source();
    final @Nullable SoundCategory category = source == null ? null : GameEnums.SOUND_SOURCE.toMinecraft(source);
    this.client.getSoundManager().stopSounds(soundIdent, category);
  }

  @Override
  public void openBook(final @NotNull Book book) {
    this.client.setScreen(new BookScreen(new BookScreen.Contents(book.pages().stream().map(this.controller::asNative).toList())));
  }

  @Override
  public void sendPlayerListHeader(final @NotNull Component header) {
    this.client.inGameHud.getPlayerListHud().setHeader(header == Component.empty() ? null : this.controller.asNative(header));
  }

  @Override
  public void sendPlayerListFooter(final @NotNull Component footer) {
    this.client.inGameHud.getPlayerListHud().setHeader(footer == Component.empty() ? null : this.controller.asNative(footer));
  }

  @Override
  public void sendPlayerListHeaderAndFooter(final @NotNull Component header, final @NotNull Component footer) {
    this.sendPlayerListHeader(header);
    this.sendPlayerListFooter(footer);
  }

  @Override
  public void sendResourcePacks(final @NotNull ResourcePackRequest request) {
    if (request.replace()) {
      this.client.getServerResourcePackProvider().removeAll();
    }

    for (final ResourcePackInfo info : request.packs()) {
      ListeningPackFeedbackWrapper.registerCallback(info.id(), request.callback(), this);

      try {
        this.client.getServerResourcePackProvider().addResourcePack(info.id(), info.uri().toURL(), info.hash());
      } catch (final MalformedURLException ex) {
        request.callback().packEventReceived(info.id(), ResourcePackStatus.INVALID_URL, this);
      }
      // TODO: required, prompting?
    }
  }

  @Override
  public void removeResourcePacks(final @NotNull UUID id, final @NotNull UUID @NotNull ... others) {
    this.client.getServerResourcePackProvider().remove(id);
    for (final UUID other : others) {
      this.client.getServerResourcePackProvider().remove(other);
    }
  }

  @Override
  public void clearResourcePacks() {
    this.client.getServerResourcePackProvider().removeAll();
  }

  @Override
  public @NotNull Pointers pointers() {
    final @Nullable ClientPlayerEntity clientPlayer = this.client.player;
    if (clientPlayer != null) {
      return AdventureCommon.pointers(clientPlayer);
    } else {
      return ((Pointered) this.client).pointers();
    }
  }
}
