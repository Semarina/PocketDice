/*
 * This file is part of adventure-platform-mod, licensed under the MIT License.
 *
 * Copyright (c) 2020-2024 KyoriPowered
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package net.kyori.adventure.platform.modcommon.impl.server;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import net.kyori.adventure.audience.MessageType;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.chat.ChatType;
import net.kyori.adventure.chat.SignedMessage;
import net.kyori.adventure.identity.Identity;
import net.kyori.adventure.inventory.Book;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.platform.modcommon.MinecraftAudiences;
import net.kyori.adventure.platform.modcommon.impl.AdventureCommon;
import net.kyori.adventure.platform.modcommon.impl.ControlledAudience;
import net.kyori.adventure.platform.modcommon.impl.GameEnums;
import net.kyori.adventure.platform.modcommon.impl.MinecraftAudiencesInternal;
import net.kyori.adventure.platform.modcommon.impl.accessor.minecraft.network.ServerGamePacketListenerImplAccess;
import net.kyori.adventure.platform.modcommon.impl.accessor.minecraft.world.level.LevelAccess;
import net.kyori.adventure.pointer.Pointers;
import net.kyori.adventure.resource.ResourcePackCallback;
import net.kyori.adventure.resource.ResourcePackInfo;
import net.kyori.adventure.resource.ResourcePackRequest;
import net.kyori.adventure.sound.Sound;
import net.kyori.adventure.sound.SoundStop;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import net.kyori.adventure.title.Title;
import net.kyori.adventure.title.TitlePart;
import net.kyori.adventure.util.MonkeyBars;
import net.minecraft.component.ComponentChanges;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.WritableBookContentComponent;
import net.minecraft.component.type.WrittenBookContentComponent;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.listener.ClientCommonPacketListener;
import net.minecraft.network.message.MessageSignatureData;
import net.minecraft.network.message.SentMessage;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.common.ResourcePackRemoveS2CPacket;
import net.minecraft.network.packet.s2c.common.ResourcePackSendS2CPacket;
import net.minecraft.network.packet.s2c.play.BundleS2CPacket;
import net.minecraft.network.packet.s2c.play.ClearTitleS2CPacket;
import net.minecraft.network.packet.s2c.play.PlaySoundFromEntityS2CPacket;
import net.minecraft.network.packet.s2c.play.PlaySoundS2CPacket;
import net.minecraft.network.packet.s2c.play.RemoveMessageS2CPacket;
import net.minecraft.network.packet.s2c.play.ScreenHandlerSlotUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.StopSoundS2CPacket;
import net.minecraft.network.packet.s2c.play.SubtitleS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleFadeS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleS2CPacket;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.RawFilteredPair;
import net.minecraft.util.Hand;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import static java.util.Objects.requireNonNull;

public class ServerPlayerAudience implements ControlledAudience {
  protected final ServerPlayerEntity player;
  private final MinecraftServerAudiencesImpl controller;

  public ServerPlayerAudience(final ServerPlayerEntity player, final MinecraftServerAudiencesImpl controller) {
    this.player = player;
    this.controller = controller;
  }

  void sendPacket(final Packet<? extends ClientCommonPacketListener> packet) {
    this.player.networkHandler.sendPacket(packet);
  }

  @SuppressWarnings({"unchecked", "rawtypes"}) // bundle generics don't handle configuration phase
  void sendBundle(final List<? extends Packet<? extends ClientCommonPacketListener>> packet) {
    this.player.networkHandler.sendPacket(new BundleS2CPacket((List) packet));
  }

  @Override
  public void sendMessage(final @NotNull Component message) {
    this.player.sendMessage(this.controller.asNative(message));
  }

  @Override
  @Deprecated
  public void sendMessage(final Identity source, final Component text, final net.kyori.adventure.audience.MessageType type) {
    final boolean shouldSend = switch (this.player.getClientChatVisibility()) {
      case FULL -> true;
      case SYSTEM -> type == MessageType.SYSTEM;
      case HIDDEN -> false;
    };

    if (shouldSend) {
      this.player.sendMessage(this.controller.asNative(text));
    }
  }

  private net.minecraft.network.message.MessageType.Parameters toMc(final ChatType.Bound adv) {
    return AdventureCommon.chatTypeToNative(adv, this.controller);
  }

  @Override
  public void sendMessage(final @NotNull Component message, final ChatType.@NotNull Bound boundChatType) {
    final SentMessage outgoing = new SentMessage.Profileless(
        this.controller.asNative(message)
    );
    this.player.sendChatMessage(outgoing, false, this.toMc(boundChatType));
  }

  @Override
  public void sendMessage(final @NotNull SignedMessage signedMessage, final ChatType.@NotNull Bound boundChatType) {
    if ((Object) signedMessage instanceof net.minecraft.network.message.SignedMessage pcm) {
      if (pcm.isSenderMissing()) {
        this.player.sendChatMessage(new SentMessage.Profileless(pcm.getContent()), false, this.toMc(boundChatType));
      } else {
        this.player.sendChatMessage(new SentMessage.Chat(pcm), false, this.toMc(boundChatType));
      }
    } else {
      this.sendMessage(Objects.requireNonNullElse(signedMessage.unsignedContent(), Component.text(signedMessage.message())), boundChatType);
    }
  }

  @Override
  public void deleteMessage(final SignedMessage.@NotNull Signature signature) {
    this.sendPacket(new RemoveMessageS2CPacket(((MessageSignatureData) (Object) signature)
      .pack(((ServerGamePacketListenerImplAccess) this.player.networkHandler).accessor$messageSignatureCache())));
  }

  @Override
  public void sendActionBar(final @NotNull Component message) {
    this.player.sendMessageToClient(this.controller.asNative(message), true);
  }

  @Override
  public void showBossBar(final @NotNull BossBar bar) {
    MinecraftServerAudiencesImpl.forEachInstance(controller -> {
      if (controller != this.controller) {
        controller.bossBars().unsubscribe(this.player, bar);
      }
    });
    this.controller.bossBars().subscribe(this.player, bar);
  }

  @Override
  public void hideBossBar(final @NotNull BossBar bar) {
    MinecraftServerAudiencesImpl.forEachInstance(controller -> controller.bossBars().unsubscribe(this.player, bar));
  }

  private long seed(final @NotNull Sound sound) {
    if (sound.seed().isPresent()) {
      return sound.seed().getAsLong();
    } else {
      return ((LevelAccess) this.player.method_37908()).accessor$threadSafeRandom().nextLong();
    }
  }

  private RegistryEntry<SoundEvent> eventHolder(final @NotNull Sound sound) {
    final var soundEventRegistry = this.controller.registryAccess()
      .getOrThrow(RegistryKeys.SOUND_EVENT);
    final var soundKey = MinecraftAudiences.asNative(sound.name());

    final var eventOptional = soundEventRegistry.getEntry(RegistryKey.of(RegistryKeys.SOUND_EVENT, soundKey));
    return eventOptional.isPresent() ? eventOptional.get() : RegistryEntry.of(SoundEvent.of(soundKey));
  }

  @Override
  public void playSound(final @NotNull Sound sound) {
    this.playSound(sound, this.player.getX(), this.player.getY(), this.player.getZ());
  }

  @Override
  public void playSound(final @NotNull Sound sound, final double x, final double y, final double z) {
    this.sendPacket(new PlaySoundS2CPacket(
      this.eventHolder(sound),
      GameEnums.SOUND_SOURCE.toMinecraft(sound.source()),
      x,
      y,
      z,
      sound.volume(),
      sound.pitch(),
      this.seed(sound)
    ));
  }

  @Override
  public void playSound(final @NotNull Sound sound, final Sound.@NotNull Emitter emitter) {
    final Entity targetEntity;
    if (emitter == Sound.Emitter.self()) {
      targetEntity = this.player;
    } else if (emitter instanceof Entity) {
      targetEntity = (Entity) emitter;
    } else {
      throw new IllegalArgumentException("Provided emitter '" + emitter + "' was not Sound.Emitter.self() or an Entity");
    }

    if (!this.player.method_37908().equals(targetEntity.method_37908())) {
      // don't send unless entities are in the same dimension
      return;
    }

    this.sendPacket(new PlaySoundFromEntityS2CPacket(
      this.eventHolder(sound),
      GameEnums.SOUND_SOURCE.toMinecraft(sound.source()),
      targetEntity,
      sound.volume(),
      sound.pitch(),
      this.seed(sound)
    ));
  }

  @Override
  public void stopSound(final @NotNull SoundStop stop) {
    final @Nullable Key sound = stop.sound();
    final Sound.@Nullable Source src = stop.source();
    final @Nullable SoundCategory cat = src == null ? null : GameEnums.SOUND_SOURCE.toMinecraft(src);
    this.sendPacket(new StopSoundS2CPacket(sound == null ? null : MinecraftAudiences.asNative(sound), cat));
  }

  @Override
  public void openBook(final @NotNull Book book) {
    if (book.pages().size() > WritableBookContentComponent.MAX_PAGE_COUNT) {
      throw new IllegalArgumentException("Book provided had " + book.pages().size() + " pages, but is only allowed a maximum of " + WritableBookContentComponent.MAX_PAGE_COUNT);
    }
    final WrittenBookContentComponent content = new WrittenBookContentComponent(
      RawFilteredPair.of(validateField(this.adventure$plain(book.title()), WrittenBookContentComponent.MAX_TITLE_LENGTH, "title")),
      this.adventure$plain(book.author()),
      0,
      book.pages().stream()
        .map(this.controller::asNative)
        .map(RawFilteredPair::passThrough)
        .toList(),
      true
    );

    final ItemStack bookStack = new ItemStack(Items.WRITTEN_BOOK, 1);
    bookStack.applyUnvalidatedChanges(
      ComponentChanges.builder()
      .add(DataComponentTypes.WRITTEN_BOOK_CONTENT, content)
      .build()
    );

    final ItemStack previous = this.player.getInventory().getSelectedStack();
    this.sendPacket(new ScreenHandlerSlotUpdateS2CPacket(-2, this.player.currentScreenHandler.getRevision(), this.player.getInventory().selectedSlot, bookStack));
    this.player.useBook(bookStack, Hand.MAIN_HAND);
    this.sendPacket(new ScreenHandlerSlotUpdateS2CPacket(-2, this.player.currentScreenHandler.getRevision(), this.player.getInventory().selectedSlot, previous));
  }

  private static String validateField(final String content, final int length, final String name) {
    if (content == null) {
      return content;
    }

    final int actual = content.length();
    if (actual > length) {
      throw new IllegalArgumentException("Field '" + name + "' has a maximum length of " + length + " but was passed '" + content + "', which was " + actual + " characters long.");
    }
    return content;
  }

  private String adventure$plain(final @NotNull Component component) {
    return PlainTextComponentSerializer.plainText().serialize(this.controller.renderer().render(component, this));
  }

  @Override
  public void showTitle(final @NotNull Title title) {
    if (title.subtitle() != Component.empty()) {
      this.sendPacket(new SubtitleS2CPacket(this.controller.asNative(title.subtitle())));
    }

    final Title.@Nullable Times times = title.times();
    if (times != null) {
      final int fadeIn = ticks(times.fadeIn());
      final int fadeOut = ticks(times.fadeOut());
      final int dwell = ticks(times.stay());
      if (fadeIn != -1 || fadeOut != -1 || dwell != -1) {
        this.sendPacket(new TitleFadeS2CPacket(fadeIn, dwell, fadeOut));
      }
    }

    if (title.title() != Component.empty()) {
      this.sendPacket(new TitleS2CPacket(this.controller.asNative(title.title())));
    }
  }

  @Override
  public <T> void sendTitlePart(final @NotNull TitlePart<T> part, final @NotNull T value) {
    Objects.requireNonNull(value, "value");
    if (part == TitlePart.TITLE) {
      this.sendPacket(new TitleS2CPacket(this.controller.asNative((Component) value)));
    } else if (part == TitlePart.SUBTITLE) {
      this.sendPacket(new SubtitleS2CPacket(this.controller.asNative((Component) value)));
    } else if (part == TitlePart.TIMES) {
      final Title.Times times = (Title.Times) value;
      final int fadeIn = ticks(times.fadeIn());
      final int fadeOut = ticks(times.fadeOut());
      final int dwell = ticks(times.stay());
      if (fadeIn != -1 || fadeOut != -1 || dwell != -1) {
        this.sendPacket(new TitleFadeS2CPacket(fadeIn, dwell, fadeOut));
      }
    } else {
      throw new IllegalArgumentException("Unknown TitlePart '" + part + "'");
    }
  }

  static int ticks(final @NotNull Duration duration) {
    return duration.getSeconds() == -1 ? -1 : (int) (duration.toMillis() / 50);
  }

  @Override
  public void clearTitle() {
    this.sendPacket(new ClearTitleS2CPacket(false));
  }

  @Override
  public void resetTitle() {
    this.sendPacket(new ClearTitleS2CPacket(true));
  }

  @Override
  public void sendPlayerListHeader(final @NotNull Component header) {
    requireNonNull(header, "header");
    AdventureCommon.HOOKS.updateTabList(this.player, this.controller.asNative(header), null);
  }

  @Override
  public void sendPlayerListFooter(final @NotNull Component footer) {
    requireNonNull(footer, "footer");
    AdventureCommon.HOOKS.updateTabList(this.player, null, this.controller.asNative(footer));
  }

  @Override
  public void sendPlayerListHeaderAndFooter(final @NotNull Component header, final @NotNull Component footer) {
    AdventureCommon.HOOKS.updateTabList(
      this.player,
      this.controller.asNative(requireNonNull(header, "header")),
      this.controller.asNative(requireNonNull(footer, "footer")));
  }

  @Override
  public void sendResourcePacks(final @NotNull ResourcePackRequest request) {
    final List<Packet<ClientCommonPacketListener>> packets = new ArrayList<>(request.packs().size());
    if (request.replace()) {
      packets.add(new ResourcePackRemoveS2CPacket(Optional.empty()));
    }

    final net.minecraft.text.@Nullable Text prompt = this.asNativeNullable(request.prompt());
    for (final Iterator<ResourcePackInfo> it = request.packs().iterator(); it.hasNext();) {
      final ResourcePackInfo pack = it.next();
      packets.add(new ResourcePackSendS2CPacket(
        pack.id(),
        pack.uri().toASCIIString(),
        pack.hash(),
        request.required(),
        it.hasNext() ? Optional.empty() : Optional.ofNullable(prompt)
      ));

      if (request.callback() != ResourcePackCallback.noOp()) {
        ((ServerCommonPacketListenerImplBridge) this.player.networkHandler).adventure$bridge$registerPackCallback(pack.id(), this.controller, request.callback());
      }
    }

    this.sendBundle(packets);
  }

  @Override
  public void removeResourcePacks(final @NotNull UUID id, final @NotNull UUID@NotNull... others) {
    this.sendBundle(
      MonkeyBars.nonEmptyArrayToList(pack -> new ClientboundResourcePackPopPacket(Optional.of(pack)), id, others)
    );
  }

  @Override
  public void clearResourcePacks() {
    this.sendPacket(new ResourcePackRemoveS2CPacket(Optional.empty()));
  }

  private net.minecraft.text.@Nullable Text asNativeNullable(final @Nullable Component comp) {
    return comp == null ? null : this.controller.asNative(comp);
  }

  @Override
  public @NotNull Pointers pointers() {
    return AdventureCommon.pointers(this.player);
  }

  @Override
  public @NotNull MinecraftAudiencesInternal controller() {
    return this.controller;
  }
}
