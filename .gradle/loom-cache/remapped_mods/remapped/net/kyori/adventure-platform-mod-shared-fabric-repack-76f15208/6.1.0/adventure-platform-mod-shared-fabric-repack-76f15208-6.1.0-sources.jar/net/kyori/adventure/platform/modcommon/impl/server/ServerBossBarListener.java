/*
 * This file is part of adventure-platform-mod, licensed under the MIT License.
 *
 * Copyright (c) 2020-2024 KyoriPowered
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package net.kyori.adventure.platform.modcommon.impl.server;

import java.util.Iterator;
import java.util.Map;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.platform.modcommon.impl.AbstractBossBarListener;
import net.kyori.adventure.platform.modcommon.impl.MinecraftAudiencesInternal;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.network.packet.s2c.play.BossBarS2CPacket;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import org.jetbrains.annotations.NotNull;

import static java.util.Objects.requireNonNull;

public class ServerBossBarListener extends AbstractBossBarListener<ServerBossBar> {
  public ServerBossBarListener(final MinecraftAudiencesInternal controller) {
    super(controller);
  }

  public void subscribe(final ServerPlayerEntity player, final BossBar bar) {
    this.minecraftCreating(requireNonNull(bar, "bar")).addPlayer(requireNonNull(player, "player"));
  }

  /*
  public void subscribeAll(final Collection<ServerPlayer> players, final BossBar bar) {
    ((ServerBossEventBridge) this.minecraftCreating(requireNonNull(bar, "bar"))).adventure$addAll(players);
  }
   */

  public void unsubscribe(final ServerPlayerEntity player, final BossBar bar) {
    this.bars.computeIfPresent(bar, (key, old) -> {
      old.removePlayer(player);
      if (old.getPlayers().isEmpty()) {
        key.removeListener(this);
        return null;
      } else {
        return old;
      }
    });
  }

  /*
  public void unsubscribeAll(final Collection<ServerPlayer> players, final BossBar bar) {
    this.bars.computeIfPresent(bar, (key, old) -> {
      ((ServerBossEventBridge) old).adventure$removeAll(players);
      if (old.getPlayers().isEmpty()) {
        key.removeListener(this);
        return null;
      } else {
        return old;
      }
    });
  }
   */

  /**
   * Replace a player entity without sending any packets.
   *
   * <p>This should be triggered when the entity representing a player changes
   * (such as during a respawn)</p>
   *
   * @param old old player
   * @param newPlayer new one
   */
  public void replacePlayer(final ServerPlayerEntity old, final ServerPlayerEntity newPlayer) {
    for (final ServerBossBar bar : this.bars.values()) {
      ((ServerBossEventBridge) bar).adventure$replaceSubscriber(old, newPlayer);
    }
  }

  /**
   * Refresh titles when a player's locale has changed.
   *
   * @param player player to refresh titles fro
   */
  public void refreshTitles(final ServerPlayerEntity player) {
    for (final ServerBossBar bar : this.bars.values()) {
      if (bar.getPlayers().contains(player)) {
        player.networkHandler.sendPacket(BossBarS2CPacket.updateName(bar));
      }
    }
  }

  /**
   * Remove the player from all associated boss bars.
   *
   * @param player The player to remove
   */
  public void unsubscribeFromAll(final ServerPlayerEntity player) {
    for (final Iterator<Map.Entry<BossBar, ServerBossBar>> it = this.bars.entrySet().iterator(); it.hasNext();) {
      final ServerBossBar bar = it.next().getValue();
      if (bar.getPlayers().contains(player)) {
        bar.removePlayer(player);
        if (bar.getPlayers().isEmpty()) {
          it.remove();
        }
      }
    }
  }

  @Override
  protected ServerBossBar newBar(
    final @NotNull Text title,
    final net.minecraft.entity.boss.BossBar.@NotNull Color color,
    final net.minecraft.entity.boss.BossBar.@NotNull Style style,
    final float progress
  ) {
    final ServerBossBar event = new ServerBossBar(title, color, style);
    event.setPercent(progress);
    return event;
  }
}
