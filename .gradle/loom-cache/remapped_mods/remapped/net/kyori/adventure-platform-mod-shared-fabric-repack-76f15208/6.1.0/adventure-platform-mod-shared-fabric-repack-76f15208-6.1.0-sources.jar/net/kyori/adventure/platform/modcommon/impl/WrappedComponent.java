/*
 * This file is part of adventure-platform-mod, licensed under the MIT License.
 *
 * Copyright (c) 2020-2024 KyoriPowered
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package net.kyori.adventure.platform.modcommon.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import net.kyori.adventure.pointer.Pointered;
import net.kyori.adventure.pointer.Pointers;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.renderer.ComponentRenderer;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import net.minecraft.text.MutableText;
import net.minecraft.text.OrderedText;
import net.minecraft.text.PlainTextContent;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextContent;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

public class WrappedComponent implements Text {
  protected Text converted;
  protected @Nullable Object deepConvertedLocalized = null;
  private final net.kyori.adventure.text.Component wrapped;
  private final @Nullable Function<Pointered, ?> partition;
  private final @Nullable ComponentRenderer<Pointered> renderer;
  private final @NonNull NonWrappingComponentSerializer nonWrappingSerializer;
  private @Nullable Object lastData;
  private @Nullable WrappedComponent lastRendered;

  public WrappedComponent(
    final net.kyori.adventure.text.Component wrapped,
    final @Nullable Function<Pointered, ?> partition,
    final @Nullable ComponentRenderer<Pointered> renderer,
    final NonWrappingComponentSerializer nonWrappingComponentSerializer
  ) {
    this.wrapped = wrapped;
    this.partition = partition;
    this.renderer = renderer;
    this.nonWrappingSerializer = nonWrappingComponentSerializer;
  }

  /**
   * Renderer to use to translate messages.
   *
   * @return the renderer, if any
   */
  public @Nullable ComponentRenderer<Pointered> renderer() {
    return this.renderer;
  }

  /**
   * Partition to use to generate cache keys.
   *
   * @return the partition, if any
   */
  public @Nullable Function<Pointered, ?> partition() {
    return this.partition;
  }

  public net.kyori.adventure.text.Component wrapped() {
    return this.wrapped;
  }

  public synchronized WrappedComponent rendered(final Pointered ptr) {
    final Object data = this.partition == null ? null : this.partition.apply(ptr);
    if (this.lastData != null && Objects.equals(data, this.lastData)) {
      return this.lastRendered;
    }
    this.lastData = data;
    return this.lastRendered = this.renderer == null ? this : AdventureCommon.HOOKS.createWrappedComponent(this.renderer.render(this.wrapped, ptr), null, null, this.nonWrappingSerializer);
  }

  public Text deepConverted() {
    Text converted = this.converted;
    if (converted == null || this.deepConvertedLocalized != null) {
      converted = this.converted = this.nonWrappingSerializer.serialize(this.wrapped);
      this.deepConvertedLocalized = null;
    }
    return converted;
  }

  @ApiStatus.OverrideOnly
  protected Text deepConvertedLocalized() {
    return this.deepConverted();
  }

  public @Nullable Text deepConvertedIfPresent() {
    return this.converted;
  }

  @Override
  public Style getStyle() {
    return this.deepConverted().getStyle();
  }

  @Override
  public String getString() {
    return PlainTextComponentSerializer.plainText().serialize(this.rendered(AdventureCommon.pointered(Pointers::empty)).wrapped);
  }

  @Override
  public String asTruncatedString(final int length) {
    return this.deepConverted().asTruncatedString(length);
  }

  @Override
  public TextContent getContent() {
    if (this.wrapped instanceof TextComponent text) {
      return new PlainTextContent.Literal(text.content());
    } else {
      return this.deepConverted().getContent();
    }
  }

  @Override
  public List<Text> getSiblings() {
    return this.deepConverted().getSiblings();
  }

  @Override
  public MutableText copyContentOnly() {
    return this.deepConverted().copyContentOnly();
  }

  @Override
  public MutableText copy() {
    return this.deepConverted().copy();
  }

  @Override
  public OrderedText asOrderedText() {
    return this.deepConvertedLocalized().asOrderedText();
  }

  @Override
  public <T> Optional<T> visit(final StyledVisitor<T> visitor, final Style style) {
    return this.deepConvertedLocalized().visit(visitor, style);
  }

  @Override
  public <T> Optional<T> visit(final Visitor<T> visitor) {
    return this.deepConverted().visit(visitor);
  }

  @Override
  public int hashCode() {
    return this.deepConverted().hashCode();
  }

  @Override
  public boolean equals(final Object obj) {
    if (obj instanceof final WrappedComponent wrappedComponent) {
      return this.wrapped().equals(wrappedComponent.wrapped());
    }
    return this.deepConverted().equals(obj);
  }
}
