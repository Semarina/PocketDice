/*
 * This file is part of adventure-platform-mod, licensed under the MIT License.
 *
 * Copyright (c) 2022-2024 KyoriPowered
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package net.kyori.adventure.platform.fabric.impl;

import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.NotNull;

import static net.kyori.adventure.platform.modcommon.impl.AdventureCommon.res;

public record ClientboundArgumentTypeMappingsPacket(Int2ObjectMap<Identifier> mappings) implements CustomPayload {
  public static final CustomPayload.Id<ClientboundArgumentTypeMappingsPacket> TYPE = new Id<>(res("registered_arg_mappings"));
  private static final PacketCodec<RegistryByteBuf, ClientboundArgumentTypeMappingsPacket> CODEC = PacketCodec.tuple(
    PacketCodecs.map(Int2ObjectArrayMap::new, PacketCodecs.VAR_INT, Identifier.PACKET_CODEC),
    ClientboundArgumentTypeMappingsPacket::mappings,
    ClientboundArgumentTypeMappingsPacket::new
  );

  public static void register() {
    PayloadTypeRegistry.playS2C().register(ClientboundArgumentTypeMappingsPacket.TYPE, ClientboundArgumentTypeMappingsPacket.CODEC);
  }

  public void sendTo(final PacketSender responder) {
    responder.sendPacket(this);
  }

  @Override
  public @NotNull Id<? extends CustomPayload> getId() {
    return TYPE;
  }
}
