/*
 * This file is part of adventure-platform-mod, licensed under the MIT License.
 *
 * Copyright (c) 2022-2024 KyoriPowered
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package net.kyori.adventure.platform.fabric.impl;

import java.util.HashSet;
import java.util.Set;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.kyori.adventure.platform.modcommon.impl.AdventureCommon;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.NotNull;

/**
 * A packet sent client to server, to let the server know which optional argument types are available on the server.
 *
 * <p>This packet is sent by players on join, before the command tree is sent to the client.</p>
 *
 * @param known Known argument type ids
 */
public record ServerboundRegisteredArgumentTypesPacket(Set<Identifier> known) implements CustomPayload {
  public static final CustomPayload.Id<ServerboundRegisteredArgumentTypesPacket> TYPE = new CustomPayload.Id<>(AdventureCommon.res("registered_args"));
  private static final PacketCodec<RegistryByteBuf, ServerboundRegisteredArgumentTypesPacket> CODEC = PacketCodec.tuple(
    PacketCodecs.collection(HashSet::new, Identifier.PACKET_CODEC),
    ServerboundRegisteredArgumentTypesPacket::known,
    ServerboundRegisteredArgumentTypesPacket::new
  );

  public static void register() {
    PayloadTypeRegistry.playC2S().register(TYPE, CODEC);
    ServerPlayNetworking.registerGlobalReceiver(TYPE, (pkt, ctx) -> {
      ctx.player().method_5682().execute(() -> { // on main thread
        ServerArgumentTypes.knownArgumentTypes(ctx.player(), pkt.known, ctx.responseSender());
      });
    });
  }

  public static ServerboundRegisteredArgumentTypesPacket of(final Set<Identifier> idents) {
    return new ServerboundRegisteredArgumentTypesPacket(Set.copyOf(idents));
  }

  /**
   * Send the client's list of identifiers to the server.
   *
   * @param sender the sender to send the packet to
   */
  public void sendTo(final PacketSender sender) {
    sender.sendPacket(this);
  }

  @Override
  public @NotNull Id<? extends CustomPayload> getId() {
    return TYPE;
  }
}
